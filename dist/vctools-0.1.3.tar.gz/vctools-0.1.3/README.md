vcloudpy
========

Functions for interfacing with VMware vCloud (both private cloud and vCloud Air).

This system is rather rudimentary at the moment, but does provide workable functionality for making remote changes to VApps from within Python. The system also includes a server module, which will launch a Tornado instance and respond to API requests from a web application.

More documentation to follow in later releases.

Contributors
------------

Ben Collier

Legal Notes
-----------

vCloud Suite, vCloud Air and vCloud Director are registered trademarks of VMware, Inc.
