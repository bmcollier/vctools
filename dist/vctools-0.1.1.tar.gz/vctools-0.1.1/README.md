vcloudpy
========

Functions for interfacing with VMware vCloud (both private cloud and vCloud Air).

vCloud Suite, vCloud Air and vCloud Director are registered trademarks of VMware, Inc.

Contributors
------------

Ben Collier

